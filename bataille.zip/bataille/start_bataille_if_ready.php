<?php
require 'auth_check.php';
header('Content-Type: application/json');

$salonId = $_GET['salon_id'] ?? null;
if (!$salonId) {
    echo json_encode(['success' => false, 'error' => 'Salon ID manquant']);
    exit;
}

// Vérifie si une partie existe déjà
$stmt = $pdo->prepare("SELECT * FROM bataille_states WHERE salon_id = ?");
$stmt->execute([$salonId]);
$etat = $stmt->fetch(PDO::FETCH_ASSOC);

if ($etat) {
    if ($etat['phase'] === 'termine') {
        // Vérifie si les joueurs ont encore des jetons
        $joueur1 = $etat['joueur1_id'];
        $joueur2 = $etat['joueur2_id'];

        $stmt = $pdo->prepare("SELECT id, tokens FROM users WHERE id IN (?, ?)");
        $stmt->execute([$joueur1, $joueur2]);
        $jetons = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        if (($jetons[$joueur1] ?? 0) <= 0 || ($jetons[$joueur2] ?? 0) <= 0) {
            echo json_encode(['success' => false, 'error' => 'Un joueur n’a plus de jetons']);
            exit;
        }

        // Réinitialise la partie
        $stmt = $pdo->prepare("UPDATE bataille_states SET
            mise_j1 = 0,
            mise_j2 = 0,
            carte_j1 = NULL,
            carte_j2 = NULL,
            phase = 'mise1',
            current_turn = ?
            WHERE salon_id = ?");
        $stmt->execute([$joueur1, $salonId]);

        $pdo->prepare("UPDATE salons SET last_activity = NOW() WHERE id = ?")->execute([$salonId]);

        echo json_encode(['success' => true, 'message' => 'Nouvelle manche lancée']);
        exit;
    } else {
        echo json_encode(['success' => true, 'message' => 'Partie déjà lancée']);
        exit;
    }
}

// Si aucune partie n'existe encore, on l'initialise
$stmt = $pdo->prepare("SELECT user_id FROM players WHERE salon_id = ? AND role = 'joueur' ORDER BY joined_at ASC LIMIT 2");
$stmt->execute([$salonId]);
$joueurs = $stmt->fetchAll(PDO::FETCH_COLUMN);

if (count($joueurs) < 2) {
    echo json_encode(['success' => false, 'error' => 'Pas assez de joueurs']);
    exit;
}

list($joueur1, $joueur2) = $joueurs;

// Création initiale
$stmt = $pdo->prepare("INSERT INTO bataille_states (salon_id, joueur1_id, joueur2_id, phase, current_turn) VALUES (?, ?, ?, 'mise1', ?)");
$stmt->execute([$salonId, $joueur1, $joueur2, $joueur1]);

echo json_encode(['success' => true, 'message' => 'Partie de bataille démarrée']);
