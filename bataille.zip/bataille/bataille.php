<?php
require 'auth_check.php';

$salonId = $_GET['salon_id'] ?? null;
$userId = $_SESSION['user_id'] ?? null;

if (!$salonId || !$userId) {
    echo "Salon ou utilisateur non défini.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bataille</title>
    <link rel="stylesheet" href="css/bataille.css">
</head>
<body>

<div id="table">
    <h1>Bataille</h1>
    <div id="info-phase">Phase : en attente</div>

    <div class="joueurs-container">
        <div id="bloc-joueur1" class="bloc-joueur">
            <h3 id="nom-joueur1">Joueur 1</h3>
            <div id="jetons-joueur1">Jetons : ?</div>
            <div id="mise-joueur1">Mise : 0</div>
            <div id="carte-joueur1"></div>
        </div>

        <div id="bloc-joueur2" class="bloc-joueur">
            <h3 id="nom-joueur2">Joueur 2</h3>
            <div id="jetons-joueur2">Jetons : ?</div>
            <div id="mise-joueur2">Mise : 0</div>
            <div id="carte-joueur2"></div>
        </div>
    </div>

    <div id="zone-mise">
        <input type="number" id="input-mise" placeholder="Votre mise">
        <button id="btn-envoyer-mise">Envoyer mise</button>
    </div>

    <button id="tirer-btn" style="display:none;">Tirer cartes</button>
    <button id="resoudre-btn" style="display:none;">Résoudre</button>

    <div id="message-fin" style="display:none;">Fin de partie</div>
</div>

<form method="POST" action="quitter_salon.php" style="padding: 10px 20px;">
    <input type="hidden" name="salon_id" value="<?= htmlspecialchars($_GET['salon_id'] ?? '') ?>">
    <button id="btn_quit" type="submit" style="padding: 10px 20px; 
    font-size: 16px;
    background-color: #990a0a;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;">Quitter le salon</button>
</form>


<script>
    window.SALON_ID = <?= json_encode($salonId) ?>;
    window.USER_ID = <?= json_encode($userId) ?>;
</script>
<script src="bataille_sync.js"></script>
</body>
</html>
