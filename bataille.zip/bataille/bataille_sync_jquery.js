const salonId = window.SALON_ID;
const userId = window.USER_ID;

console.log("Bataille (jQuery) sync initialisée", { salonId, userId });

function mapToFilename(nomCarte) {
    const [valeur, couleur] = nomCarte.split("_");
    const valeursMap = {
        "AS": "ace", "VALET": "jack", "DAME": "queen", "ROI": "king",
        "2": "2", "3": "3", "4": "4", "5": "5", "6": "6",
        "7": "7", "8": "8", "9": "9", "10": "10"
    };
    const couleursMap = {
        "COEUR": "hearts", "CARREAU": "diamonds",
        "TREFLE": "clubs", "PIQUE": "spades"
    };
    return `${valeursMap[valeur]}_of_${couleursMap[couleur]}`;
}

function afficherCarte(idContainer, nomCarte) {
    const container = $("#" + idContainer);
    container.empty();
    if (!nomCarte) return;

    const img = $("<img>").addClass("carte").attr("src", `/casino/PNG-cards/${mapToFilename(nomCarte)}.png`);
    container.append(img);
}

function envoyerMise(valeur) {
    $.post("jouer_bataille.php", {
        salon_id: salonId,
        action: "mise",
        mise: valeur
    }, function (data) {
        if (!data.success) alert(data.error);
    }, "json");
}

function tirerCartes() {
    $.post("jouer_bataille.php", {
        salon_id: salonId,
        action: "tirer"
    }, function () {}, "json");
}

function resoudre() {
    $.post("jouer_bataille.php", {
        salon_id: salonId,
        action: "résoudre"
    }, function (data) {
        if (data.success) {
            if (data.egalite) alert("Égalité !");
            else if (data.gagnant == userId) alert("🎉 Vous avez gagné !");
            else alert("💀 Vous avez perdu.");
        }
    }, "json");
}

function chargerEtat() {
    $.get("get_bataille_state.php", { salon_id: salonId }, function (data) {
        if (!data.success) return;

        const phase = data.status;
        const estMonTour = data.current_turn == userId;

        $("#info-phase").text(`Phase : ${phase}`);
        afficherCarte("carte-joueur1", data.carte_j1);
        afficherCarte("carte-joueur2", data.carte_j2);

        $("#nom-joueur1").text(data.nom_joueur1 || "Joueur 1");
        $("#nom-joueur2").text(data.nom_joueur2 || "Joueur 2");
        $("#jetons-joueur1").text("Jetons : " + (data.jetons_joueur1 ?? "?"));
        $("#jetons-joueur2").text("Jetons : " + (data.jetons_joueur2 ?? "?"));

        $("#bloc-joueur1").toggleClass("actif", data.current_turn == data.joueur1_id);
        $("#bloc-joueur2").toggleClass("actif", data.current_turn == data.joueur2_id);

        if ((phase === "mise1" && userId === data.joueur1_id) || (phase === "mise2" && userId === data.joueur2_id)) {
            $("#zone-mise").show();
        } else {
            $("#zone-mise").hide();
        }

        $("#tirer-btn").toggle(phase === "tirage");
        $("#resoudre-btn").toggle(phase === "résultat");
        $("#message-fin").toggle(phase === "termine");
    }, "json");
}

function lancerPartieSiBesoin() {
    $.get("start_bataille_if_ready.php", { salon_id: salonId }, function (data) {
        console.log("Start partie :", data);
    }, "json");
}

// Rafraîchissement régulier
setInterval(() => {
    chargerEtat();
    lancerPartieSiBesoin();
}, 3000);

// Événements
$("#btn-envoyer-mise").on("click", function () {
    const mise = parseInt($("#input-mise").val());
    if (mise > 0) envoyerMise(mise);
});

$("#tirer-btn").on("click", tirerCartes);
$("#resoudre-btn").on("click", resoudre);
