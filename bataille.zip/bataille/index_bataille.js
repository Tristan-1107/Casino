function loadSalons() {
    fetch("salons.php")
        .then(response => {
            if (!response.ok) throw new Error("Erreur lors du chargement des salons.");
            return response.text();
        })
        .then(html => {
            document.getElementById("salons-list").innerHTML = html;
        })
        .catch(error => {
            console.error("Erreur : ", error);
            document.getElementById("salons-list").innerHTML = "<p>Erreur de chargement des salons.</p>";
        });
}

// Nettoyage périodique (inchangé)
setInterval(() => {
    fetch("clean_salons.php").catch(() => {});
}, 60000);

document.addEventListener("DOMContentLoaded", () => {
    loadSalons();
    setInterval(loadSalons, 3000);
});
