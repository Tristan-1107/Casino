<?php
require_once 'auth_check.php';
require_once 'config.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit;
}
$salon_id = (int) $_GET['id'];
$user_id = $_SESSION['user_id'];

// Vérifie que l'utilisateur appartient à ce salon
$stmt = $pdo->prepare("SELECT * FROM players WHERE user_id = ? AND salon_id = ?");
$stmt->execute([$user_id, $salon_id]);
$player = $stmt->fetch();

if (!$player) {
    header("Location: index.php");
    exit;
}

// Récupère les informations du salon
$stmt = $pdo->prepare("SELECT * FROM salons WHERE id = ?");
$stmt->execute([$salon_id]);
$salon = $stmt->fetch();

if (!$salon) {
    echo "Salon introuvable.";
    exit;
}

// Récupération de tous les utilisateurs connectés à cette salle
$stmt = $pdo->prepare("
    SELECT u.username, u.tokens, p.role
    FROM players p
    JOIN users u ON p.user_id = u.id
    WHERE p.salon_id = ?
");
$stmt->execute([$salon_id]);
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Salle - <?= htmlspecialchars($salon['name']) ?></title>
    <link rel="stylesheet" href="css/style.css">
    <script>
        const salonId = <?= $salon_id ?>;
    </script>
    <script src="js/blackjack_engine.js" defer></script>
</head>
<body>
    <header>
        <div class="logo">MyCasino – <?= htmlspecialchars($salon['name']) ?></div>
        <div class="user-info">
            Vous êtes connecté en tant que <?= htmlspecialchars($_SESSION['username']) ?> –
            <a href="logout.php" class="logout">Déconnexion</a>
        </div>
    </header>

    <main>
        <section class="infos-salon">
            <h2>Participants</h2>
            <ul>
                <?php foreach ($users as $u): ?>
                    <li><?= htmlspecialchars($u['username']) ?> (<?= $u['role'] ?> – <?= $u['tokens'] ?> jetons)</li>
                <?php endforeach; ?>
            </ul>
        </section>

        <section class="table-jeu">
            <h2>Table de Blackjack</h2>
            <div>
                <h3>Cartes du croupier</h3>
                <div id="dealer-hand" class="hand"></div>
            </div>

            <div>
                <h3>Vos cartes</h3>
                <div id="player-hand" class="hand"></div>
            </div>

            <p id="game-status">En attente...</p>

            <?php if ($player['role'] === 'joueur'): ?>
                <button id="btn-hit">Tirer</button>
                <button id="btn-stand">Rester</button>
            <?php else: ?>
                <p>Vous êtes spectateur. La partie est en cours.</p>
            <?php endif; ?>
        </section>
    </main>
</body>
</html>
