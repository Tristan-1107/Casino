// --- fichier : bataille_sync.js ---
const salonId = window.SALON_ID;
const userId = window.USER_ID;

let aTire = false;
let aResolu = false;

console.log("Bataille sync initialisée", { salonId, userId });

const boutonMise = document.getElementById("btn-envoyer-mise");
const champMise = document.getElementById("input-mise");
const boutonTirer = document.getElementById("tirer-btn");
const boutonResoudre = document.getElementById("resoudre-btn");

function mapToFilename(nomCarte) {
    const [valeur, couleur] = nomCarte.split("_");
    const valeursMap = {
        "AS": "ace", "VALET": "jack", "DAME": "queen", "ROI": "king",
        "2": "2", "3": "3", "4": "4", "5": "5", "6": "6",
        "7": "7", "8": "8", "9": "9", "10": "10"
    };
    const couleursMap = {
        "COEUR": "hearts", "CARREAU": "diamonds",
        "TREFLE": "clubs", "PIQUE": "spades"
    };
    return `${valeursMap[valeur]}_of_${couleursMap[couleur]}`;
}

function afficherCarte(idContainer, nomCarte) {
    const container = document.getElementById(idContainer);
    if (!container) return;
    container.innerHTML = "";
    if (!nomCarte) return;
    const img = document.createElement("img");
    img.className = "carte";
    img.src = `/casino/PNG-cards/${mapToFilename(nomCarte)}.png`;
    container.appendChild(img);
}

function envoyerMise(valeur) {
    fetch("jouer_bataille.php", {
        method: "POST",
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `salon_id=${salonId}&action=mise&mise=${valeur}`
    })
    .then(r => r.json())
    .then(data => {
        if (!data.success) alert(data.error);
    })
    .catch(err => console.error("Erreur lors de l'envoi de la mise :", err));
}

function tirerCartes() {
    fetch("jouer_bataille.php", {
        method: "POST",
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `salon_id=${salonId}&action=tirer`
    }).catch(err => console.error("Erreur tirage :", err));
    aTire = true;
}

function resoudre() {
    fetch("jouer_bataille.php", {
        method: "POST",
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `salon_id=${salonId}&action=résoudre`
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            if (data.egalite) alert("Égalité !");
            else if (data.gagnant == userId) alert("Vous avez gagné !");
            else alert("Vous avez perdu.");
        }
    })
    .catch(err => console.error("Erreur résolution :", err));
    aResolu = true;
}

function chargerEtat() {
    fetch(`get_bataille_state.php?salon_id=${salonId}`)
        .then(r => r.text())
        .then(text => {
            try {
                const data = JSON.parse(text);
                if (!data.success) return;
                const estMonTour = data.current_turn == userId;
                const phase = data.status;

                if (phase === "mise1") {
                    aTire = false;
                    aResolu = false;
                }

                document.getElementById("info-phase").textContent = `Phase : ${phase}`;
                afficherCarte("carte-joueur1", data.carte_j1);
                afficherCarte("carte-joueur2", data.carte_j2);

                document.getElementById("nom-joueur1").textContent = data.nom_joueur1 || "Joueur 1";
                document.getElementById("nom-joueur2").textContent = data.nom_joueur2 || "Joueur 2";
                document.getElementById("jetons-joueur1").textContent = `Jetons : ${data.jetons_joueur1 ?? "?"}`;
                document.getElementById("jetons-joueur2").textContent = `Jetons : ${data.jetons_joueur2 ?? "?"}`;
                document.getElementById("mise-joueur1").textContent = `Mise : ${data.mise_j1 ?? 0}`;
                document.getElementById("mise-joueur2").textContent = `Mise : ${data.mise_j2 ?? 0}`;


                document.getElementById("bloc-joueur1").classList.toggle("actif", data.current_turn == data.joueur1_id);
                document.getElementById("bloc-joueur2").classList.toggle("actif", data.current_turn == data.joueur2_id);

                const zoneMise = document.getElementById("zone-mise");
                if (zoneMise) {
                    zoneMise.style.display = (phase === "mise1" && userId === data.joueur1_id)
                        || (phase === "mise2" && userId === data.joueur2_id)
                        ? "block" : "none";
                }

                if (boutonTirer) boutonTirer.style.display = "none";
                if (boutonResoudre) boutonResoudre.style.display = "none";

                const fin = document.getElementById("message-fin");
                if (fin) fin.style.display = (phase === "termine") ? "block" : "none";

                if (phase === "tirage" && userId === data.joueur1_id && !aTire) {
                    aTire = true;
                    setTimeout(tirerCartes, 1500);
                }

                if (phase === "résultat" && !aResolu) {
                    setTimeout(resoudre, 3000);
                }

            } catch (e) {
                console.error("Réponse non valide JSON :", text);
            }
        })
        .catch(err => console.error("Erreur fetch état :", err));
}

function lancerPartieSiBesoin() {
    fetch(`start_bataille_if_ready.php?salon_id=${salonId}`)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.message === "Partie déjà lancée") {
                console.log("Partie déjà lancée");
            }
        })
        .catch(err => console.error("Erreur lancement partie :", err));
}

setInterval(() => {
    chargerEtat();
    lancerPartieSiBesoin();
}, 3000);

if (boutonMise && champMise) {
    boutonMise.addEventListener("click", () => {
        const mise = parseInt(champMise.value);
        if (mise > 0) envoyerMise(mise);
    });
}
