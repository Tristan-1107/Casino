<?php
require_once 'auth_check.php';
require_once 'config.php';

// Supprimer les salons vides depuis plus de 2 minutes
$pdo->prepare("
    DELETE FROM salons 
    WHERE nb_joueurs = 0 AND nb_spectateurs = 0 
    AND TIMESTAMPDIFF(SECOND, last_activity, NOW()) > 120
")->execute();

// Récupérer les salons existants
$stmt = $pdo->query("SELECT * FROM salons ORDER BY created_at DESC");
$salons = $stmt->fetchAll();

if (empty($salons)) {
    echo "<p>Aucun salon disponible pour l’instant.</p>";
} else {
    foreach ($salons as $salon) {
        $nb_joueurs = $salon['nb_joueurs'] ?? 0;
        $nb_spectateurs = $salon['nb_spectateurs'] ?? 0;

        echo "<div class='salon-box'>";
        echo "<h3>" . htmlspecialchars($salon['game_type']) . "</h3>";
        echo "<p><strong>Nom :</strong> " . htmlspecialchars($salon['name']) . "</p>";
        echo "<p>Joueurs : " . (int)$nb_joueurs . " / " . $salon['max_participants'] . "</p>";
        echo "<p>Spectateurs : " . (int)$nb_spectateurs . "</p>";
        echo "<a href='join_salon.php?id=" . $salon['id'] . "'>Rejoindre</a>";
        echo "</div>";
    }
}
