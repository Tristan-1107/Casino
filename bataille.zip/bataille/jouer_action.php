<?php
// jouer_action.php
require_once "auth_check.php";
session_start();

$user_id = $_SESSION['user_id'] ?? null;
$salon_id = $_POST['salon_id'] ?? null;
$action = $_POST['action'] ?? null;

if (!$user_id || !$salon_id || !$action) {
    http_response_code(400);
    echo json_encode(["error" => "Paramètres manquants"]);
    exit;
}

$sql = "SELECT * FROM blackjack_states WHERE salon_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$salon_id]);
$state = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$state || $state['status'] !== 'en_cours') {
    echo json_encode(["error" => "Partie non disponible"]);
    exit;
}

$current_turn = $state['current_turn'];
$current_id = $state['joueur_actuel_id'];
if ((int)$user_id !== (int)$current_id) {
    echo json_encode(["error" => "Ce n'est pas votre tour"]);
    exit;
}

// Exemple simple de traitement : on ajoute une carte fictive
function ajouterCarte($main) {
    $deck = ["2_COEUR", "3_PIQUE", "4_TREFLE", "5_CARREAU"];
    $carte = $deck[array_rand($deck)];
    return $main === '' ? $carte : $main . "," . $carte;
}

$main_key = $current_turn === 'joueur1' ? 'joueur1_hand' : 'joueur2_hand';
$new_main = ajouterCarte($state[$main_key]);

// Mettre à jour la main et le timer
$update = $pdo->prepare("UPDATE blackjack_states SET $main_key = ?, timer_expiration = DATE_ADD(NOW(), INTERVAL 30 SECOND) WHERE salon_id = ?");
$update->execute([$new_main, $salon_id]);

echo json_encode(["success" => true, "new_hand" => $new_main]);
