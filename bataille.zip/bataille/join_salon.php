<?php
require_once "config.php";
if (session_status() === PHP_SESSION_NONE) session_start();

$user_id = $_SESSION['user_id'] ?? null;
$salon_id = $_POST['salon_id'] ?? $_GET['id'] ?? null;

if (!$user_id) {
    // ⚠️ Empêche l'accès direct sans session valide
    header("Location: login.php?error=connexion_requise");
    exit;
}

if (!$salon_id) {
    http_response_code(400);
    echo json_encode(["error" => "Paramètres manquants"]);
    exit;
}

// Retirer l'utilisateur de tout ancien salon
$pdo->prepare("DELETE FROM players WHERE user_id = ?")->execute([$user_id]);

// Compter les joueurs existants
$stmt = $pdo->prepare("SELECT COUNT(*) FROM players WHERE salon_id = ? AND role = 'joueur'");
$stmt->execute([$salon_id]);
$count = $stmt->fetchColumn();
$role = ($count < 2) ? 'joueur' : 'spectateur';

// Ajouter le joueur
$stmt = $pdo->prepare("INSERT INTO players (user_id, salon_id, role) VALUES (?, ?, ?)");
$stmt->execute([$user_id, $salon_id, $role]);

// Recalculer nb_joueurs / nb_spectateurs
$counts = $pdo->prepare("
    SELECT 
        SUM(CASE WHEN role = 'joueur' THEN 1 ELSE 0 END) AS joueurs,
        SUM(CASE WHEN role = 'spectateur' THEN 1 ELSE 0 END) AS spectateurs
    FROM players
    WHERE salon_id = ?
");
$counts->execute([$salon_id]);
$res = $counts->fetch(PDO::FETCH_ASSOC);

$pdo->prepare("UPDATE salons SET nb_joueurs = ?, nb_spectateurs = ?, last_activity = NOW() WHERE id = ?")
    ->execute([$res['joueurs'], $res['spectateurs'], $salon_id]);

// Redirection
header("Location: bataille.php?salon_id=$salon_id");
exit;
