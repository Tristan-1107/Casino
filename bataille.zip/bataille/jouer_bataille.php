<?php
require 'auth_check.php';

header('Content-Type: application/json');

$salonId = $_POST['salon_id'] ?? null;
$userId = $_SESSION['user_id'] ?? null;
$action = $_POST['action'] ?? null;
$mise = isset($_POST['mise']) ? intval($_POST['mise']) : null;

if (!$salonId || !$userId || !$action) {
    echo json_encode(['success' => false, 'error' => 'Paramètres manquants']);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM bataille_states WHERE salon_id = ?");
$stmt->execute([$salonId]);
$etat = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$etat) {
    echo json_encode(['success' => false, 'error' => 'Aucune partie trouvée']);
    exit;
}

// Récupération des jetons du joueur
$stmt = $pdo->prepare("SELECT tokens FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Utilisateur introuvable']);
    exit;
}
$jetonsActuels = intval($user['tokens']);

// Phase de mise1
if ($etat['phase'] === 'mise1' && $etat['joueur1_id'] == $userId && $action === 'mise' && $mise > 0) {
    if ($mise > $jetonsActuels) {
        echo json_encode(['success' => false, 'error' => 'Pas assez de jetons']);
        exit;
    }

    // Déduire les jetons
    $stmt = $pdo->prepare("UPDATE users SET tokens = tokens - ? WHERE id = ?");
    $stmt->execute([$mise, $userId]);

    $stmt = $pdo->prepare("UPDATE bataille_states SET mise_j1 = ?, phase = 'mise2', current_turn = ? WHERE salon_id = ?");
    $stmt->execute([$mise, $etat['joueur2_id'], $salonId]);

    $pdo->prepare("UPDATE salons SET last_activity = NOW() WHERE id = ?")->execute([$salonId]);

    echo json_encode(['success' => true]);
    exit;
}

// Phase de mise2
if ($etat['phase'] === 'mise2' && $etat['joueur2_id'] == $userId && $action === 'mise' && $mise >= $etat['mise_j1']) {
    if ($mise > $jetonsActuels) {
        echo json_encode(['success' => false, 'error' => 'Pas assez de jetons']);
        exit;
    }

    // Déduire les jetons
    $stmt = $pdo->prepare("UPDATE users SET tokens = tokens - ? WHERE id = ?");
    $stmt->execute([$mise, $userId]);

    $stmt = $pdo->prepare("UPDATE bataille_states SET mise_j2 = ?, phase = 'tirage', current_turn = NULL WHERE salon_id = ?");
    $stmt->execute([$mise, $salonId]);

    $pdo->prepare("UPDATE salons SET last_activity = NOW() WHERE id = ?")->execute([$salonId]);

    echo json_encode(['success' => true]);
    exit;
}

// Phase de tirage
if ($etat['phase'] === 'tirage' && $action === 'tirer') {
    $valeurs = ['2','3','4','5','6','7','8','9','10','VALET','DAME','ROI','AS'];
    $couleurs = ['COEUR','CARREAU','TREFLE','PIQUE'];

    shuffle($valeurs);
    shuffle($couleurs);
    $carteJ1 = $valeurs[0] . '_' . $couleurs[0];

    shuffle($valeurs);
    shuffle($couleurs);
    $carteJ2 = $valeurs[0] . '_' . $couleurs[0];

    $stmt = $pdo->prepare("UPDATE bataille_states SET carte_j1 = ?, carte_j2 = ?, phase = 'résultat' WHERE salon_id = ?");
    $stmt->execute([$carteJ1, $carteJ2, $salonId]);

    $pdo->prepare("UPDATE salons SET last_activity = NOW() WHERE id = ?")->execute([$salonId]);

    echo json_encode(['success' => true, 'carte_j1' => $carteJ1, 'carte_j2' => $carteJ2]);
    exit;
}

// Phase de résultat
if ($etat['phase'] === 'résultat' && $action === 'résoudre') {
    $valeursMap = [
        '2'=>2, '3'=>3, '4'=>4, '5'=>5, '6'=>6, '7'=>7, '8'=>8, '9'=>9, '10'=>10,
        'VALET'=>11, 'DAME'=>12, 'ROI'=>13, 'AS'=>14
    ];

    $v1 = $valeursMap[explode('_', $etat['carte_j1'])[0]] ?? 0;
    $v2 = $valeursMap[explode('_', $etat['carte_j2'])[0]] ?? 0;

    $gagnant = null;
    if ($v1 > $v2) $gagnant = $etat['joueur1_id'];
    elseif ($v2 > $v1) $gagnant = $etat['joueur2_id'];

    $miseJ1 = intval($etat['mise_j1']);
    $miseJ2 = intval($etat['mise_j2']);

    if ($gagnant === $etat['joueur1_id']) {
        $gain = min($miseJ2, $miseJ1);
        $stmt = $pdo->prepare("UPDATE users SET tokens = tokens + ? WHERE id = ?");
        $stmt->execute([$gain + $miseJ1, $etat['joueur1_id']]);
        // J2 perd tout
    } elseif ($gagnant === $etat['joueur2_id']) {
        $gain = min($miseJ1, $miseJ2);
        $stmt = $pdo->prepare("UPDATE users SET tokens = tokens + ? WHERE id = ?");
        $stmt->execute([$gain + $miseJ2, $etat['joueur2_id']]);
        // J1 perd tout
    } else {
        // Égalité : chacun récupère sa mise
        $stmt = $pdo->prepare("UPDATE users SET tokens = tokens + ? WHERE id = ?");
        $stmt->execute([$miseJ1, $etat['joueur1_id']]);
        $stmt->execute([$miseJ2, $etat['joueur2_id']]);
    }

    $stmt = $pdo->prepare("UPDATE bataille_states SET phase = 'termine' WHERE salon_id = ?");
    $stmt->execute([$salonId]);

    $pdo->prepare("UPDATE salons SET last_activity = NOW() WHERE id = ?")->execute([$salonId]);

    echo json_encode(['success' => true, 'gagnant' => $gagnant, 'egalite' => !$gagnant]);
    exit;
}

echo json_encode(['success' => false, 'error' => 'Action non valide']);
