<?php
require 'auth_check.php';
require 'config.php';
header('Content-Type: application/json');

$salonId = $_GET['salon_id'] ?? null;
$userId = $_SESSION['user_id'] ?? null;

if (!$salonId || !$userId) {
    echo json_encode(['success' => false, 'error' => 'Paramètres manquants']);
    exit;
}

// Récupération de l'état du jeu
$stmt = $pdo->prepare("SELECT * FROM bataille_states WHERE salon_id = ?");
$stmt->execute([$salonId]);
$etat = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$etat) {
    echo json_encode(['success' => false, 'error' => 'Aucune partie trouvée']);
    exit;
}



// Récupération des joueurs (pour noms et jetons)
$stmt = $pdo->prepare("SELECT id, username, tokens FROM users WHERE id IN (?, ?)");
$stmt->execute([$etat['joueur1_id'], $etat['joueur2_id']]);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Construction de la réponse JSON
$response = [
    'success' => true,
    'players' => [$etat['joueur1_id'], $etat['joueur2_id']],
    'status' => $etat['phase'],
    'joueur1_id' => $etat['joueur1_id'],
    'joueur2_id' => $etat['joueur2_id'],
    'mise_j1' => $etat['mise_j1'],
    'mise_j2' => $etat['mise_j2'],
    'carte_j1' => $etat['carte_j1'],
    'carte_j2' => $etat['carte_j2'],
    'current_turn' => $etat['current_turn'],
    'user_id' => $userId
];


// Ajouter noms et jetons
foreach ($users as $u) {
    if ($u['id'] == $etat['joueur1_id']) {
        $response['nom_joueur1'] = $u['username'];
        $response['jetons_joueur1'] = $u['tokens'];
    }
    if ($u['id'] == $etat['joueur2_id']) {
        $response['nom_joueur2'] = $u['username'];
        $response['jetons_joueur2'] = $u['tokens'];
    }
}

echo json_encode($response);
