<?php
require_once 'auth_check.php';
require_once 'config.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$salon_id = (int) $_GET['id'];
$user_id = $_SESSION['user_id'];

// Vérifie si le salon existe
$stmt = $pdo->prepare("SELECT * FROM salons WHERE id = ?");
$stmt->execute([$salon_id]);
$salon = $stmt->fetch();

if (!$salon) {
    echo "Salon inexistant.";
    exit;
}

// Vérifie si l'utilisateur est déjà dans ce salon
$stmt = $pdo->prepare("SELECT * FROM players WHERE user_id = ? AND salon_id = ?");
$stmt->execute([$user_id, $salon_id]);
$existing = $stmt->fetch();

if ($existing) {
    // Déjà dans le salon → redirection vers la salle
    header("Location: salle.php?id=" . $salon_id);
    exit;
}

// Compte les joueurs actuels
$stmt = $pdo->prepare("SELECT COUNT(*) FROM players WHERE salon_id = ? AND role = 'joueur'");
$stmt->execute([$salon_id]);
$joueurs_actuels = (int) $stmt->fetchColumn();

if ($joueurs_actuels < 2) {
    // Peut rejoindre comme joueur
    $role = 'joueur';
    $pdo->prepare("UPDATE salons SET nb_joueurs = nb_joueurs + 1, last_activity = NOW() WHERE id = ?")->execute([$salon_id]);
} else {
    // Sinon rejoint comme spectateur
    $role = 'spectateur';
    $pdo->prepare("UPDATE salons SET nb_spectateurs = nb_spectateurs + 1, last_activity = NOW() WHERE id = ?")->execute([$salon_id]);
}

// Insère dans la table players
$stmt = $pdo->prepare("INSERT INTO players (user_id, salon_id, role, joined_at) VALUES (?, ?, ?, NOW())");
$stmt->execute([$user_id, $salon_id, $role]);

// Redirection vers la salle
header("Location: salle.php?id=" . $salon_id);
exit;
