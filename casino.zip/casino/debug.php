<?php
require 'config.php';

$salon_id = $_GET['salon_id'] ?? null;
if (!$salon_id) {
    die("Aucun salon_id fourni");
}

echo "<h2>DEBUG SALON ID $salon_id</h2>";

// 🔍 Voir les joueurs
$stmt = $pdo->prepare("SELECT * FROM players WHERE salon_id = ?");
$stmt->execute([$salon_id]);
$players = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Table players</h3><pre>";
print_r($players);
echo "</pre>";

// 🔍 Voir l’état de la partie
$stmt = $pdo->prepare("SELECT * FROM blackjack_states WHERE salon_id = ?");
$stmt->execute([$salon_id]);
$etat = $stmt->fetch(PDO::FETCH_ASSOC);

echo "<h3>Table blackjack_states</h3><pre>";
print_r($etat);
echo "</pre>";
