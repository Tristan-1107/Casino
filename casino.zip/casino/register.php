<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if ($username && $password) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = "Ce pseudo est déjà utilisé.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $pdo->prepare("INSERT INTO users (username, password_hash, tokens) VALUES (?, ?, ?)")
                ->execute([$username, $hash, 1000]);
            header('Location: login.php');
            exit;
        }
    } else {
        $error = "Tous les champs sont obligatoires.";
    }
}
?>  

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta cahrset="UTF-8">
    <meta name="viexport" content="width=device-width initial-scale=1.0"> 
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudfare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
    crossorigin="anonymous" referrepolicy="no-referrer" />
</head>

<body>
   
    <header>
        <h1>
            <span> MyCasino.fr </span>
        </h1>
    </header>

    <div id="contenu">
        <h2>
            <span id="titreCreerCompte"> Créer un compte </span>
        </h2>
        <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <form method="post">
                <div class="form-group">
                    <label for="login">Identifiant</label>
                    <input type="text" id="identifiant" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Mot de passe</label>
                    <input type="password" id="password" name="password">
                </div>
                <input id="login" type="submit" value="S’inscrire">
        </form>

        <p>
            ou
        </p>
        <div>
            <br>
            <a id="creerCompte" href="login.php">Se connecter</a>
        </div>

    </div>

</body>
<footer>
     <p>
        Les jeux d'argent et de hasard sont interdit aux mineurs. 
        <br>
        Jouer comporte des risques : dépendance, isolement… Appelez le 09 74 75 13 13 (appel non surtaxé)
    </p>
</footer>

