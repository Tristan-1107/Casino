<?php
require_once 'auth_check.php';
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['salon_name'])) {
    $name = trim($_POST['salon_name']);

    // Préparation de la création d’un salon de blackjack
    $stmt = $pdo->prepare("
        INSERT INTO salons (name, game_type, creator_id, status, nb_joueurs, nb_spectateurs, max_participants, last_activity)
        VALUES (?, 'Blackjack', ?, 'waiting', 0, 0, 2, NOW())
    ");
    $stmt->execute([$name, $_SESSION['user_id']]);
}

// Redirection vers la page d'accueil
header("Location: index.php");
exit;
