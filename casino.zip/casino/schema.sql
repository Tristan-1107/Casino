-- Table des utilisateurs
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    tokens INT DEFAULT 1000,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Table des salons (blackjack uniquement pour l’instant)
CREATE TABLE salons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    game_type VARCHAR(50) DEFAULT 'Blackjack',
    creator_id INT,
    status ENUM('waiting', 'playing', 'finished') DEFAULT 'waiting',
    nb_joueurs INT DEFAULT 0,
    nb_spectateurs INT DEFAULT 0,
    max_participants INT DEFAULT 2,
    last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (creator_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Table des participants (joueurs ou spectateurs)
CREATE TABLE players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    salon_id INT NOT NULL,
    role ENUM('joueur', 'spectateur') NOT NULL,
    joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (salon_id) REFERENCES salons(id) ON DELETE CASCADE
);

-- État du jeu de blackjack pour chaque salon
CREATE TABLE blackjack_states (
    id INT AUTO_INCREMENT PRIMARY KEY,
    salon_id INT NOT NULL,
    deck TEXT NOT NULL,                      -- JSON ou chaîne de cartes restantes
    joueur1_hand TEXT DEFAULT '',            -- JSON ou chaîne (ex: "AS_COEUR,10_PIQUE")
    joueur2_hand TEXT DEFAULT '',
    croupier_hand TEXT DEFAULT '',
    joueur1_stand BOOLEAN DEFAULT FALSE,
    joueur2_stand BOOLEAN DEFAULT FALSE,
    joueur1_done BOOLEAN DEFAULT FALSE,
    joueur2_done BOOLEAN DEFAULT FALSE,
    current_turn ENUM('joueur1', 'joueur2', 'croupier') DEFAULT 'joueur1',
    status ENUM('en_cours', 'termine') DEFAULT 'en_cours',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (salon_id) REFERENCES salons(id) ON DELETE CASCADE
);
