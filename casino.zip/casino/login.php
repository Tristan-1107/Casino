<?php
session_start();
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT id, password_hash FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $username;
        header('Location: index.php');
        exit;
    } else {
        $error = "Identifiants incorrects.";
    }
}
?>



<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viexport" content="width=device-width initial-scale=1.0"> 
    <link rel="stylesheet" href="css/login.css">
</head>

<body>

    <header>
        <h1>
            <span> MyCasino.fr </span>
        </h1>
    </header>

    <main>

        
        <div id="contenu">
            <h2 id="se_connecter">
                <span> Se connecter </span>
            </h2>
            
            <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
            <form method="post">
                <div class="form-group">
                    <label for="login">Identifiant</label>
                    <input type="text" id="identifiant" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Mot de passe</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <input id="login" type="submit" value="Se connecter">
            </form>
                
            </form>
            <p>
                ou
            </p>
            <div>
                <br>
                <a id="creerCompte" href="register.php">Créer un compte</a>
            </div>
        </div>
    </main>

    <footer>
        <p>
        Les jeux d'argent et de hasard sont interdit aux mineurs. 
        <br>
        Jouer comporte des risques : dépendance, isolement… Appelez le 09 74 75 13 13 (appel non surtaxé)
        </p>

    </footer>
   

</body>


