<?php
require_once "config.php";

$salon_id = $_GET['salon_id'] ?? null;
if (!$salon_id) {
    http_response_code(400);
    echo json_encode(["error" => "salon_id manquant"]);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM blackjack_states WHERE salon_id = ?");
$stmt->execute([$salon_id]);
$state = $stmt->fetch(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT user_id, role FROM players WHERE salon_id = ? ORDER BY joined_at ASC");
$stmt->execute([$salon_id]);
$players = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$state) {
    echo json_encode([
        "status" => "not_started",
        "players" => $players
    ]);
    exit;
}


$stmt = $pdo->prepare("SELECT user_id, role FROM players WHERE salon_id = ? ORDER BY joined_at ASC");
$stmt->execute([$salon_id]);
$players = $stmt->fetchAll(PDO::FETCH_ASSOC);

$response = [
    "deck" => $state['deck'],
    "joueur1_hand" => $state['joueur1_hand'],
    "joueur2_hand" => $state['joueur2_hand'],
    "croupier_hand" => $state['croupier_hand'],
    "joueur1_stand" => (bool) ($state['joueur1_stand'] ?? false),
    "joueur2_stand" => (bool) ($state['joueur2_stand'] ?? false),
    "current_turn" => $state['current_turn'],
    "joueur_actuel_id" => $state['joueur_actuel_id'],
    "timer_expiration" => $state['timer_expiration'] ?? null,
    "status" => $state['status'],
    "players" => $players
];

header('Content-Type: application/json');
echo json_encode($response);
