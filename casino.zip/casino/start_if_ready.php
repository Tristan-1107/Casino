<?php
require_once "config.php";

$salon_id = $_GET['salon_id'] ?? null;
if (!$salon_id) {
    http_response_code(400);
    exit;
}

file_put_contents(__DIR__ . "/debug_start_ready.txt", "[".date("H:i:s")."] START - salon $salon_id\n", FILE_APPEND);

$stmt = $pdo->prepare("SELECT COUNT(*) FROM players WHERE salon_id = ? AND role = 'joueur'");
$stmt->execute([$salon_id]);
$count = $stmt->fetchColumn();
file_put_contents(__DIR__ . "/debug_start_ready.txt", "[".date("H:i:s")."] joueurs = $count\n", FILE_APPEND);

if ((int)$count === 2) {
    $stmt = $pdo->prepare("SELECT id FROM blackjack_states WHERE salon_id = ?");
    $stmt->execute([$salon_id]);
    $existing = $stmt->fetch();

    $stmt = $pdo->prepare("SELECT user_id FROM players WHERE salon_id = ? AND role = 'joueur' ORDER BY joined_at ASC LIMIT 1");
    $stmt->execute([$salon_id]);
    $joueur1_id = $stmt->fetchColumn();

    if (!$existing) {
        file_put_contents(__DIR__ . "/debug_start_ready.txt", "[".date("H:i:s")."] CREATING blackjack_states\n", FILE_APPEND);
        $stmt = $pdo->prepare("INSERT INTO blackjack_states (salon_id, deck, joueur1_hand, joueur2_hand, croupier_hand, current_turn, status, joueur_actuel_id)
            VALUES (?, '', '', '', '', 'joueur1', 'waiting', ?)");
        $stmt->execute([$salon_id, $joueur1_id]);
    }

    $deck = ["2_COEUR", "3_COEUR", "4_COEUR", "5_COEUR", "6_COEUR"];
    shuffle($deck);
    $j1 = array_shift($deck) . "," . array_shift($deck);
    $j2 = array_shift($deck) . "," . array_shift($deck);
    $croupier = array_shift($deck);

    $stmt = $pdo->prepare("UPDATE blackjack_states SET 
        deck = ?, joueur1_hand = ?, joueur2_hand = ?, croupier_hand = ?, 
        current_turn = 'joueur1', status = 'en_cours', joueur_actuel_id = ?, 
        updated_at = NOW()
        WHERE salon_id = ?");
    $stmt->execute([
        implode(",", $deck), $j1, $j2, $croupier, $joueur1_id, $salon_id
    ]);

    file_put_contents(__DIR__ . "/debug_start_ready.txt", "[".date("H:i:s")."] Partie lancée\n", FILE_APPEND);
    echo json_encode(["status" => "partie_lancee"]);
} else {
    echo json_encode(["status" => "attente_joueurs"]);
}
