<?php
require_once 'auth_check.php';
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
// Récupération de l'utilisateur connecté
$stmt = $pdo->prepare("SELECT username, tokens FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>MyCasino – Accueil</title>
    <link rel="stylesheet" href="css/style.css">
    
</head>
<body>
    <header>
        <div class="logo">MyCasino</div>
        <div class="user-info">
            <?= htmlspecialchars($user['username']) ?> – <?= $user['tokens'] ?> jetons
            <a href="logout.php" class="logout">Déconnexion</a>
        </div>
    </header>

    <main>
        <section class="create-salon">
            <h2>Créer un salon</h2>
            <form action="create_salon.php" method="POST">
                <input type="text" name="salon_name" placeholder="Nom du salon" required>
                <!-- <input type="text" name="nb_places" placeholder="Nombres de joueurs" required> -->
                <button type="submit">Créer</button>
            </form>
        </section>  

        <section class="salons">
            <h2>Salons disponibles</h2>
            <div id="salons-list">
                Chargement des salons en cours...
            </div>
        </section>
    </main>

    <script src="js/index.js" defer></script>
</body>
</html>
