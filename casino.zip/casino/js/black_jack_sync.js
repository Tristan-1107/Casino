// black_jack_sync.js

const salonId = window.SALON_ID;
const userId = window.USER_ID;
console.log("DEBUG SALON_ID:", salonId);
console.log("DEBUG USER_ID:", userId);


function jouer(action) {
    fetch("jouer_action.php", {
        method: "POST",
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `salon_id=${salonId}&action=${action}`
    })
    .then(r => r.json())
    .then(data => {
        if (!data.success) alert(data.error);
        desactiverBoutons();
    });
}

function afficherMain(role, mainStr, estActif = false) {
    const main = document.getElementById(`hand-${role}`);
    main.innerHTML = "";
    if (!mainStr) return;

    const cards = mainStr.split(",");
    let total = 0;

    cards.forEach(carte => {
        const img = document.createElement("img");
        img.className = "carte";
        img.style.width = "60px";
        img.style.marginRight = "5px";

        const nom = carte.trim();
        if (!nom) return;

        const mapped = mapToFilename(nom);
        img.src = `/casino/PNG-cards/${mapped}.png`;
        main.appendChild(img);

        total += getCardValue(nom);
    });

    const totalDiv = document.createElement("div");
    totalDiv.className = "main-total";
    totalDiv.textContent = `Total: ${total}`;
    totalDiv.style.marginTop = "5px";
    totalDiv.style.color = "white";
    main.appendChild(totalDiv);

    if (estActif) {
        main.style.border = "3px solid yellow";
        main.style.borderRadius = "10px";
    } else {
        main.style.border = "none";
    }
}

function mapToFilename(nomCarte) {
    const [valeur, couleur] = nomCarte.split("_");
    const valeursMap = {
        "AS": "ace", "VALET": "jack", "DAME": "queen", "ROI": "king",
        "2": "2", "3": "3", "4": "4", "5": "5", "6": "6", "7": "7",
        "8": "8", "9": "9", "10": "10"
    };
    const couleursMap = {
        "COEUR": "hearts", "CARREAU": "diamonds", "TREFLE": "clubs", "PIQUE": "spades"
    };
    return `${valeursMap[valeur]}_of_${couleursMap[couleur]}`;
}

function getCardValue(nomCarte) {
    const [valeur] = nomCarte.split("_");
    if (valeur === "AS") return 11;
    if (["ROI", "DAME", "VALET"].includes(valeur)) return 10;
    return parseInt(valeur);
}

function activerBoutons() {
    document.getElementById("hit").disabled = false;
    document.getElementById("stand").disabled = false;
    document.getElementById("double").disabled = false;
}

function desactiverBoutons() {
    document.getElementById("hit").disabled = true;
    document.getElementById("stand").disabled = true;
    document.getElementById("double").disabled = true;
}

function lancerPartieSiPossible() {
    fetch(`start_if_ready.php?salon_id=${salonId}`)
        .then(r => r.json())
        .then(data => console.log("Réponse start_if_ready:", data));
}

setInterval(() => {
    fetch(`get_game_state.php?salon_id=${salonId}`)
        .then(r => r.json())
        .then(data => {
            const players = Array.isArray(data.players) ? data.players : [];

            console.log("DEBUG STATUS:", data.status);
            console.log("DEBUG players:", data.players);

            if ((data.status !== "en_cours" || !data.status) && players.length >= 2) {
                lancerPartieSiPossible();
            }

            const estMonTour = data.joueur_actuel_id == userId;

            afficherMain("joueur1", data.joueur1_hand, data.current_turn === "joueur1");
            afficherMain("joueur2", data.joueur2_hand, data.current_turn === "joueur2");
            afficherMain("croupier", data.croupier_hand);

            if (estMonTour) {
                activerBoutons();
            } else {
                desactiverBoutons();
            }

            if (players.length >= 2 && data.status === "en_cours") {
                document.getElementById("message-attente").style.display = "none";
            } else {
                document.getElementById("message-attente").style.display = "block";
            }

            if (data.status === "termine") {
                alert("Fin de partie");
            }
        });
}, 3000);

document.getElementById("hit").addEventListener("click", () => jouer("hit"));
document.getElementById("stand").addEventListener("click", () => jouer("stand"));
document.getElementById("double").addEventListener("click", () => jouer("double"));
