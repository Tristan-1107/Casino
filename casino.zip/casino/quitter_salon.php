<?php
// quitter_salon.php
require_once "config.php";
if (session_status() === PHP_SESSION_NONE) session_start();

$user_id = $_SESSION['user_id'] ?? null;
$salon_id = $_POST['salon_id'] ?? null;

if (!$user_id || !$salon_id) {
    http_response_code(400);
    exit("Paramètres manquants");
}

// Supprimer le joueur du salon
$stmt = $pdo->prepare("DELETE FROM players WHERE user_id = ? AND salon_id = ?");
$stmt->execute([$user_id, $salon_id]);

// Recalculer les compteurs de joueurs et spectateurs
$counts = $pdo->prepare("
    SELECT 
        SUM(CASE WHEN role = 'joueur' THEN 1 ELSE 0 END) AS joueurs,
        SUM(CASE WHEN role = 'spectateur' THEN 1 ELSE 0 END) AS spectateurs
    FROM players
    WHERE salon_id = ?
");
$counts->execute([$salon_id]);
$res = $counts->fetch(PDO::FETCH_ASSOC);

// Mettre à jour le salon
$pdo->prepare("
    UPDATE salons 
    SET nb_joueurs = ?, nb_spectateurs = ?, last_activity = NOW() 
    WHERE id = ?
")->execute([$res['joueurs'], $res['spectateurs'], $salon_id]);

// Si plus aucun joueur, marquer le salon comme terminé
if ((int)$res['joueurs'] === 0) {
    $pdo->prepare("UPDATE salons SET status = 'finished' WHERE id = ?")->execute([$salon_id]);
}

// Rediriger vers l'accueil
header("Location: index.php");
exit;
