<?php
require_once 'config.php';

// Supprimer tous les salons inactifs (vides depuis plus de 2 minutes)
$stmt = $pdo->prepare("
    DELETE FROM salons 
    WHERE nb_joueurs = 0 
    AND nb_spectateurs = 0 
    AND TIMESTAMPDIFF(SECOND, last_activity, NOW()) > 120
");
$stmt->execute();
