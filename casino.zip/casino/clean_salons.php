<?php
// clean_salons.php
require_once "config.php";

// Supprimer les salons sans joueur depuis plus d'une minute
$sql = "
    DELETE s, b
    FROM salons s
    LEFT JOIN players p ON s.id = p.salon_id
    LEFT JOIN blackjack_states b ON b.salon_id = s.id
    WHERE p.id IS NULL AND s.last_activity < (NOW() - INTERVAL 1 MINUTE)
";

$pdo->prepare($sql)->execute();
