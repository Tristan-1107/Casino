<?php
if (session_status() === PHP_SESSION_NONE) session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <title>BlackJack Connecté</title>
  <link rel="stylesheet" href="css/blackJack.css">
  <script>
    window.SALON_ID = <?= isset($_GET['salon_id']) ? (int)$_GET['salon_id'] : 'null' ?>;
    window.USER_ID = <?= isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 'null' ?>;
  </script>
</head>
<body>
  <h1>Blackjack</h1>
  <script> console.log("JS chargé !")</script>
  <div id="message-attente">En attente d’un autre joueur...</div>

  <div class="table">
        <div class="zone" id="zone-croupier">
            <div>
                <h2>Croupier</h2>
                <div class="cartes" id="hand-croupier"></div>
            </div>
        </div>

        <div class="zone" id="zone-joueur1">
            <div>
                <h2>Joueur 1</h2>
                <div class="cartes" id="hand-joueur1"></div>
            </div>
        </div>

        <div class="zone" id="zone-joueur2">
            <div>
                <h2>Joueur 2</h2>
                <div class="cartes" id="hand-joueur2"></div>
            </div>
        </div>
  </div>

  <div class="controls">
    <button id="hit" disabled>Hit</button>
    <button id="stand" disabled>Stand</button>
    <button id="double" disabled>Double</button>
    <form method="POST" action="quitter_salon.php" onsubmit="return confirm('Quitter la partie ?');">
      <input type="hidden" name="salon_id" value="<?= (int)$_GET['salon_id'] ?>">
      <button type="submit">Quitter le salon</button>
    </form>
  </div>

  <script src="js/black_jack_sync.js"></script>
</body>
</html>
